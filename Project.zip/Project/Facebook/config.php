<?php
session_start();
//session_destroy();
require_once('Facebook/autoload.php');

$FBObject = new \Facebook\Facebook([
	'app_id' => '2567618326650414',
	'app_secret' => 'c8b61f81c4a8a9227268ead295ee7f8d',
	'default_graph_version' => 'v2.10'
]);


$handler = $FBObject -> getRedirectLoginHelper();
?>