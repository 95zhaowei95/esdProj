<?php
session_start();

if(!isset($_SESSION['access_token'])){
	header("Location: login.php");
	exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Healthiest</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <!-- Custom styles for this template -->
  <link href="css/agency.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
      <b class="navbar-brand js-scroll-trigger" href="#page-top"> Healthiest</b>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation" >
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <b class="nav-link js-scroll-trigger" href="#services">BMI</b>
          </li>
          <li class="nav-item">
            <b class="nav-link js-scroll-trigger" href="#about">Running</b>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Header -->
  <header class="masthead">
    <div class="container">
		        <div class="intro-text">
				    <div class="intro-lead-in">Welcome <?php echo $_SESSION['userData']['first_name'] ?> !</div>
					<div class="intro-heading text-uppercase">Lets measure your health status</div>
		
						<form role="form" id="search-form" class="form">		
						
								<div class="form-group">											
										<label for="nric">Please Enter your Height and Weight:</label>
											<input class="form-control" type="text" id="weight" placeholder="weight">
											<input class="form-control" type="text" id="height" placeholder="height">													
								</div>
							
							
								<button id="btn" type="submit" class="btn btn-primary center-block">Submit &rarr; </button>
							
							
						</form>
				
					<h id="results-header" class="text-center text-info"></h>
					<div id="results"></div>
				
				</div>
    </div>
  </header>




    <script>
       $(function () {
            $("#search-form").submit(function (event) {
                var height = $('#height').val().trim();
				var weight = $('#weight').val().trim();
                // simple validation check of input & error message
				if ( height == '' || weight == '') {
                    $("#results-header").html("<font color=red>Your input was invalid, please try again<br><br></font>");
                    $("#results").html("");
                    return false;
                }
				if (isNaN(height) || isNaN(weight)) {
                    $("#results-header").html("<font color=red>We require your input to be numeric<br><br></font>");
                    $("#results").html("");
                    return false;
                }
                $.get("http://10.124.2.98:8080/BMI/" + weight + "&" + height , function (data) {
                    if (data.result == undefined) {
                        $("#results-header").html("<font color=red>The Values you entered is invalid or cannot be calculated<br><br></font>");
                        $("#results").html("");
                    } else {
                        // Placing the data within a table
                        var tableContent = 
                            "<table class='table' id='results-table'>"+
                                "<tr><td><b>BMI</b></td><td>"      + data.result + "</td></tr>" +
                                "<tr><td><b>Health Status</b></td><td>"      + data.status + "</td></tr>" +
								//how to get data out of the json array?
					            "<tr><td><b>Recommended weight for Women</b></td><td>"      + data.ideal_weight[0] + "</td></tr>" +
                                "<tr><td><b>Recommended weight for men</b></td><td>"      + data.ideal_weight + "</td></tr>" +
                            "</table>";
                        $("#results-header").html("<font color=white> Hey <?php echo $_SESSION['userData']['first_name'] ?>! This is your current health status:" );
                        $("#results").html(tableContent);
                    }
                }) // $.get()
                    .fail(function () {
                        $("#results-header").html("<font color=red>There is a problem in retrieving the information, please try again later.<br><br></font>");
                        $("#results").html("");
                    })
                // This prevents the submit button to continue it's default behaviour to submit so that the page doesn't refresh and stays here
                event.preventDefault();

            });
        });
    </script>