<!DOCTYPE html>
<html lang="en">

<head>
    <title>Central Medical Center</title>
    <!-- HEAD
          This is where you put your jQuery, Bootstrap JS library imports
        -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
        crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>

<body style="background-color:rgb(241, 241, 231)">
    <!-- BODY
          This is where you put your html presentation code and Bootstrap JS related
          tags, markups, etc
        -->
    <div class="container">
        <div class="row">
            <div class="jumbotron align-items-center justify-content-center col-md-offset-2 col-md-8">
                <center><img src="http://www.drbradjacobs.com/wp-content/uploads/2013/02/healthy-eating-nutrition-workshops.jpg" width="100%"></center>
                <h2 class="text-center text-info">Health Application Login Page </h2>
                <br />
                <form role="form" id="search-form" class="form">
                    <div class="form-group"><label for="id">Enter customer's Name:</label><input class="form-control"
                            type="text" id="name" placeholder="customer's name">
                    </div>
                    <button id="btn" type="submit" class="btn btn-primary center-block">Submit &rarr; </button>
                </form>

                <h4 id="results-header" class="text-center text-info"></h4>
                <div id="results"></div>
            </div>
        </div>
    </div>

    <script>
        /* Script
        Place the script tag at the end of the body tag so the contents are loaded
        first before the scripts.
        This is where you put all your javascript and/or jQuery scripts for
        dynamically changing any html contents.
        */
        $(function () {
            $("#search-form").submit(function (event) {
                var input = $('#name').val().trim();
                // simple validation check of input & error message
                if (input == '') {
                    $("#results-header").html("<font color=red>This is not a valid name.<br><br></font>");
                    $("#results").html("");
                    return false;
                }
                $.get("http://localhost:3000/customer/" + input, function (data) {
                    if (data.name == undefined) {
                        $("#results-header").html("<font color=red>Your name could not be found.<br><br></font>");
                        $("#results").html("");
                    } else {
                        // Placing the data within a table
                        var tableContent = 
                            "<table class='table' id='results-table'>"+
                                "<tr><td><b>id</b></td><td>"      + data.id + "</td></tr>" +
                                "<tr><td><b>Name</td></br><td>"     + data.name + "</td></tr>" +
                                "<tr><td><b>email</b></td><td>" + data.email + "</td></tr>" +
                                "<tr><td><b>telegram</b></td><td>"    + data.telegram + "</td></tr>" +
                            "</table>";
                        $("#results-header").html(" Results for customer with name " + document.getElementById('name').value);
                        $("#results").html(tableContent);
                    }
                }) // $.get()
                    .fail(function () {
                        $("#results-header").html("<font color=red>There is a problem in retrieving the information, please try again later.<br><br></font>");
                        $("#results").html("");
                    })
                // This prevents the submit button to continue it's default behaviour to submit so that the page doesn't refresh and stays here
                event.preventDefault();

            });
        });
    </script>
</body>

</html>